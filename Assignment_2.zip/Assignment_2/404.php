<?php
$title = "Not Found";
require('header.php');
?>

<h1>Ooops!</h1>

<p>We've looked everywhere but we can't find that page.  Please try one of the links above.</p>

</body>
</html>
