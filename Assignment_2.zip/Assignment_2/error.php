<?php
$title = "Error";
require('header.php');
?>

<h1>Ooops!</h1>

<p>Something went wrong.  Don't worry, we've been notified and are looking into it.</p>

</body>
</html>