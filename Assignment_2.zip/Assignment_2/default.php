<?php
$title = "Movies";
require('header.php');
?>

<main class="well text-center">
    <h1 class="">Movies</h1>
    <p>This site was created for Assignment No.2 By Rupinder Singh.It uses PHP, MySQL, and Twitter Bootstrap and is deployed to AWS.</p>
    <p>Source Code is available at <a href="https://github.com/ifotn/comp1006-barrie-eats">
            https://github.com/ifotn/comp1006-barrie-eats</a>.</p>
</main>

</body>
</html>
