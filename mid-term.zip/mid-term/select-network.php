<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Networks</title>
</head>
<body>

<a href="ViewShows.php">View Shows</a>
<h1>Networks</h1>
<form method="post" action="ViewShows.php">
    <fieldset>
        <label for="networkName" class="col-md-1">Type: </label>
        <select name="networkName" id="networkName">
            <option>-Select-</option>
            <?php
            $db = new PDO('mysql:host=aws.computerstudi.es;dbname=gc200397613', 'gc200397613', 'eedZzT8hO_');
            $sql = "SELECT networkName FROM networks";
            $cmd = $db->prepare($sql);
            $cmd->execute();
            $networkName = $cmd->fetchAll();
            foreach ($networkName as $n) {
                if ($n['networkName'] == $networkName) {
                    echo "<option selected> {$n['networkName']} </option>";
                }
                else {
                    echo "<option> {$n['networkName']} </option>";
                }
            }
            $db = null;
            ?>
        </select>
    </fieldset>
    <button class="col-md-offset-1 btn btn-primary">Save</button>
</form>
</body>
</html>