<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Restaurants</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body>
<a href="select-network.php">View Shows</a>
<h1>View Shows</h1>

<?php
$db = new PDO('mysql:host=aws.computerstudi.es;dbname=gc200397613', 'gc200397613', 'eedZzT8hO_');
$sql = "SELECT * FROM shows";


$cmd = $db->prepare($sql);
$cmd->execute();
$shows = $cmd->fetchAll();
echo '<table class="table table-striped table-hover"><thead><th>showName</th><th>firstYear</th><th>networkName</th></thead>';

foreach ($shows as $s) {
    echo "<tr><td> {$s['showName']} </td>
        <td> {$s['firstYear']} </td>
        <td> {$s['networkName']} </td></tr>";
}

echo '</table>';
$db = null;
?>

<!-- js -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/scripts.js"></script>

</body>
</html>
>