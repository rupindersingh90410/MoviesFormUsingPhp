<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Network_Dropdown</title>
</head>
<body>
<?php
$db = new PDO('mysql:host=aws.computerstudi.es;dbname=gc200397613', 'gc200397613', 'eedZzT8hO_');

$sql = "SELECT networkName FROM networks ORDER";
$cmd = $db->prepare($sql);
$cmd->execute();
$networkName = $cmd->fetchAll();
echo '<select networkName="networkName">';

foreach ($networkName as $n) {
    echo '<option>' . $n['networkName'] . '</option>';
}
echo '</select>';
$db = null;
?>
</body>
</html>